#!/bin/bash

ps aux | grep titan_service | grep -v grep | awk '{print $2}'
