#!/bin/bash

if [ $1 != "stop" ] && [ $1 != "start" ];then
	echo "请运行参数start or stop | ./install.sh start"
fi

touch ./log/yyets_node.log

case $1 in

	start )
	/usr/bin/killall yyets_node >./log/yyets_node.log 2>&1 &
	/usr/bin/killall yyets_check >./log/yyets_node.log 2>&1 &
	sleep 1
	./yyets_node >./log/yyets_node.log 2>&1 &
	check=`ps -ef|grep yyets_check|grep -v grep|grep -v /bin/sh|wc -l`
	if [ $check -eq '0' ];then
	./yyets_check >/dev/null 2>&1 &
	fi
	sleep 1
	yyets=`ps -ef|grep yyets_node|grep -v grep|grep -v /bin/sh|wc -l`
	if [ $yyets -eq '1' ];then
	echo "yyets_node:程序启动成功"
	fi
	;;
	
	stop )
	/usr/bin/killall yyets_node >./log/yyets_node.log 2>&1 &
	sleep 1
	cd ext/titan && ./stop.sh && cd ../../
	cd ext/xyipk && ./stop.sh && cd ../../
	yyets=`ps -ef|grep yyets_node|grep -v grep|grep -v /bin/sh|wc -l`
	if [ $yyets -eq '0' ];then
	echo "yyets_node:程序关闭成功"
	fi
	;;
esac


