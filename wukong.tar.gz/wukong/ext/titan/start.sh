#!/bin/bash

cd $1
./titan_service -p 12127 -q $2 -u 0x0001000A &
