#!/bin/bash

curr_dir=$(cd `dirname $0`; pwd)
sys_dir="${curr_dir}/../system"
tmp_dir="/tmp/.xyapp"
log_file="${tmp_dir}/xyipk.log"

mon_name="xyipk_monitor"
mon_path="${curr_dir}/${mon_name}"
exe_full_name="${curr_dir}/bin/xyipk"
log_file="${tmp_dir}/xyipk.log"

log()
{
	local time=`date "+%Y-%m-%d %H:%M:%S"`
	echo "${time} <pid $$> $*" >> ${log_file}
}


log "stop plugins and xyipk"

stop_plugins()
{
	for d in ${sys_dir}/miner.*.ipk
	do
		if [ -f "${d}/stop.sh" ]; then
			log "stop plugin ${d}"
			${d}/stop.sh > /dev/null 2>&1 &
		fi
	done
}

stop_xyipk()
{
	local monitor_pids=`ps -ef | grep ${mon_name} | grep -v grep | awk '{ printf $2 " " }'`
	if [ -n "${monitor_pids}" ]; then
		log "stop xyipk monitor, pids ${monitor_pids}"
		kill ${monitor_pids}
	fi
	
	local exe_pids=`ps -ef | grep ${exe_full_name} | grep -v grep | awk '{ printf $2 " " }'`
	if [ -n "${exe_pids}" ]; then
		log "stop xyipk, pids ${exe_pids}"
		kill -9 ${exe_pids}
	fi
}

stop_plugins
stop_xyipk
