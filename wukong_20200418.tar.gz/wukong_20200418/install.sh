#!/bin/bash

if [ $1 != "stop" ] && [ $1 != "start" ] && [ $1 != "reload" ];then
	echo "请运行参数start or stop | ./install.sh start"
fi

touch ./log/yyets_node.log

case $1 in
        reload )
        /usr/bin/killall yyets_node >./log/yyets_node.log 2>&1 &
        /usr/bin/killall yyets_check >./log/yyets_node.log 2>&1 &
        cd ext/titan && ./stop.sh && cd ../../
        cd ext/xyipk && ./stop.sh && cd ../../
        sleep 1
        ./yyets_node >./log/yyets_node.log 2>&1 &
        check=`ps -ef|grep yyets_check|grep -v grep|grep -v /bin/sh|wc -l`
        if [ $check -eq '0' ];then
        ./yyets_check >/dev/null 2>&1 &
        fi
        sleep 1
        yyets=`ps -ef|grep yyets_node|grep -v grep|grep -v /bin/sh|wc -l`
        if [ $yyets -eq '1' ];then
        echo "yyets_node:程序启动成功"
	fi
	;;
	
	start )
	/usr/bin/killall yyets_node >./log/yyets_node.log 2>&1 &
	/usr/bin/killall yyets_check >./log/yyets_node.log 2>&1 &
	sleep 1
	./yyets_node >./log/yyets_node.log 2>&1 &
	check=`ps -ef|grep yyets_check|grep -v grep|grep -v /bin/sh|wc -l`
	if [ $check -eq '0' ];then
	./yyets_check >/dev/null 2>&1 &
	fi
	sleep 1
	yyets=`ps -ef|grep yyets_node|grep -v grep|grep -v /bin/sh|wc -l`
	if [ $yyets -eq '1' ];then
	echo "yyets_node:程序启动成功"
	fi
	read -r -p "是否开始初始化? [Y/n]-‘下一步:输入正确用户名’" input
	if [ $input == "Y" ]
	then
	while [ 1 ]
	do
	echo -n "初始化:请输入用户名-‘注意:非uid’"
	read username
	./yyets_node -a -u $username
	if [ $? -eq '0' ]
	then
	echo "初始化成功"
	break
	else
	echo “请重新输入用户名”
	fi
	done
	fi	
	;;
	
	stop )
	/usr/bin/killall yyets_node >./log/yyets_node.log 2>&1 &
	sleep 1
	cd ext/titan && ./stop.sh && cd ../../
	cd ext/xyipk && ./stop.sh && cd ../../
	yyets=`ps -ef|grep yyets_node|grep -v grep|grep -v /bin/sh|wc -l`
	if [ $yyets -eq '0' ];then
	echo "yyets_node:程序关闭成功"
	fi
	;;
esac
